from __future__ import annotations

import json
import argparse
import signal
import sys
import os
import logging
from typing import Any, Dict, Optional

from . import state
from .math import easing

from .engine.mods import apply_mods
from .engine.advance import load_from_args
from .renderer import run as run_renderer
from .config_v2 import dump_config_v2, flatten_config_v2, load_config_v2
from .i18n import normalize_lang, pick_lang_from_config, tr
from .logging_setup import setup_logging
from .api.playlist import run_playlist_script

# Global respack instance (kept for backward-compat with the original single-file code)
respack: Optional[Any] = None

def build_arg_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="phic_renderer")
    g_in = ap.add_argument_group("Input")
    g_in.add_argument("--input", required=False, default=None, help="chart.json OR chart pack folder OR .zip/.pez pack")
    g_in.add_argument("--advance", type=str, default=None)
    g_in.add_argument("--playlist_script", type=str, default=None, help="Run a playlist script (python file)")
    g_in.add_argument("--playlist_charts_dir", type=str, default="charts")
    g_in.add_argument("--playlist_notes_per_chart", type=int, default=10)
    g_in.add_argument("--playlist_tail_time", type=float, default=0.5)
    g_in.add_argument("--playlist_seed", type=int, default=None)
    g_in.add_argument("--playlist_no_shuffle", action="store_true")
    g_in.add_argument("--playlist_switch_mode", type=str, default="hit", choices=["hit", "judged"])
    g_in.add_argument("--playlist_filter_levels", type=str, default=None)
    g_in.add_argument("--playlist_filter_name_contains", type=str, default=None)
    g_in.add_argument("--playlist_filter_min_total_notes", type=int, default=None)
    g_in.add_argument("--playlist_filter_max_total_notes", type=int, default=None)
    g_in.add_argument("--playlist_filter_limit", type=int, default=None)
    g_in.add_argument("--playlist_start_mode", type=str, default="fresh", choices=["fresh", "resume"])
    g_in.add_argument("--playlist_start_index", type=int, default=None)
    g_in.add_argument("--playlist_start_from_hit_total", type=int, default=None)
    g_in.add_argument("--playlist_start_from_combo_total", type=int, default=None)

    g_cfg = ap.add_argument_group("Config")
    g_cfg.add_argument("--config", type=str, default=None, help="Config v2 (JSONC) path")
    g_cfg.add_argument("--config_old", type=str, default=None, help="Legacy config (plain JSON) path")
    g_cfg.add_argument("--save_config", type=str, default=None, help="Write config v2 (JSONC) to this path")

    g_cui = ap.add_argument_group("CUI")
    g_cui.add_argument("--lang", type=str, default=None, help="Language: zh-CN / en")
    g_cui.add_argument("--quiet", action="store_true", help="Less console output")
    g_cui.add_argument("--no_color", action="store_true", help="Disable ANSI colors")

    g_win = ap.add_argument_group("Window")
    g_win.add_argument("--w", type=int, default=1280)
    g_win.add_argument("--h", type=int, default=720)

    g_render = ap.add_argument_group("Render")
    g_render.add_argument("--approach", type=float, default=3.0, help="Seconds ahead to draw")
    g_render.add_argument("--chart_speed", type=float, default=1.0)
    g_render.add_argument("--no_cull", action="store_true", help="Draw all notes (can be slow)")
    g_render.add_argument("--no_cull_screen", action="store_true", help="Disable screen-space visibility culling")
    g_render.add_argument("--no_cull_enter_time", action="store_true", help="Disable t_enter / time-window culling")
    g_render.add_argument("--note_scale_x", type=float, default=1.0)
    g_render.add_argument("--note_scale_y", type=float, default=1.0)
    g_render.add_argument("--note_flow_speed_multiplier", type=float, default=1.0)
    g_render.add_argument("--expand", type=float, default=1.0)
    g_render.add_argument("--overrender", type=float, default=2.0)
    g_render.add_argument("--trail_alpha", type=float, default=0.0)
    g_render.add_argument("--trail_blur", type=int, default=0)
    g_render.add_argument("--trail_dim", type=int, default=0)
    g_render.add_argument("--hitfx_scale_mul", type=float, default=1.0)
    g_render.add_argument("--multicolor_lines", action="store_true")
    g_render.add_argument("--no_note_outline", action="store_true")
    g_render.add_argument("--line_alpha_affects_notes", type=str, default="negative_only", choices=["never", "negative_only", "always"])
    g_render.add_argument(
        "--backend",
        type=str,
        default="pygame",
        choices=["pygame", "moderngl", "gl", "opengl"],
        help="Render backend",
    )

    g_assets = ap.add_argument_group("Assets")
    g_assets.add_argument("--respack", type=str, default=None, help="Respack zip path")
    g_assets.add_argument("--bg", type=str, default=None, help="Background image path")
    g_assets.add_argument("--bg_blur", type=int, default=10, help="Blur strength (downscale factor)")
    g_assets.add_argument("--bg_dim", type=int, default=120, help="Dark overlay alpha 0..255")

    g_audio = ap.add_argument_group("Audio")
    g_audio.add_argument("--bgm", type=str, default=None, help="BGM audio file path (ogg/mp3/wav)")
    g_audio.add_argument("--force", action="store_true", help="Force using --bgm (or config audio.bgm) even if input is a chart pack that provides music")
    g_audio.add_argument("--bgm_volume", type=float, default=0.8)
    g_audio.add_argument(
        "--audio_backend",
        type=str,
        default="pygame",
        choices=["pygame", "openal", "al"],
        help="Audio backend",
    )
    g_audio.add_argument("--hitsound_min_interval_ms", type=int, default=30)

    g_game = ap.add_argument_group("Gameplay")
    g_game.add_argument("--autoplay", action="store_true")
    g_game.add_argument("--simulateplay", action="store_true")
    g_game.add_argument("--simulateplay_mode", type=str, default="conservative", choices=["conservative", "aggressive", "extreme"])
    g_game.add_argument("--simulateplay_max_pointers", type=int, default=2)
    g_game.add_argument("--simulateplay_ipad", action="store_true", help="Route simulateplay gestures to a real iPad via Appium (preview window shows iPad screen)")
    g_game.add_argument("--ipad_bundle_id", type=str, default=None, help="iOS app bundleId to control (required for --simulateplay_ipad)")
    g_game.add_argument("--ipad_udid", type=str, default=None, help="Target device UDID (optional if Appium can pick one)")
    g_game.add_argument("--ipad_device_name", type=str, default="iPad")
    g_game.add_argument("--ipad_appium_server", type=str, default="http://127.0.0.1:4723")
    g_game.add_argument("--ipad_mjpeg_url", type=str, default=None, help="Optional MJPEG stream URL for low-latency preview")
    g_game.add_argument("--ipad_move_hz", type=float, default=25.0, help="Max move events per second sent to iPad")
    g_game.add_argument("--ipad_preview_fps", type=float, default=15.0, help="iPad screenshot preview FPS (0 disables)")
    g_game.add_argument("--ipad_max_retries", type=int, default=2)
    g_game.add_argument("--ipad_retry_backoff_s", type=float, default=0.35)
    g_game.add_argument("--ipad_reconnect", action="store_true", help="Reconnect Appium session on failure")
    g_game.add_argument("--ipad_activate_app", action="store_true", help="Activate app on connect (disabled by default to avoid forcing reopen)")
    g_game.add_argument("--ipad_viewport_x0", type=float, default=0.0, help="Viewport mapping x0 (normalized 0..1 in device screen)")
    g_game.add_argument("--ipad_viewport_y0", type=float, default=0.0, help="Viewport mapping y0 (normalized 0..1 in device screen)")
    g_game.add_argument("--ipad_viewport_x1", type=float, default=1.0, help="Viewport mapping x1 (normalized 0..1 in device screen)")
    g_game.add_argument("--ipad_viewport_y1", type=float, default=1.0, help="Viewport mapping y1 (normalized 0..1 in device screen)")
    g_game.add_argument("--judge_script", type=str, default=None, help="Optional judge script JSON to simulate non-perfect autoplay")
    g_game.add_argument("--hold_fx_interval_ms", type=int, default=200)
    g_game.add_argument("--hold_tail_tol", type=float, default=0.8)
    g_game.add_argument("--judge_width", type=float, default=0.12, help="Judgement width as ratio of screen width")
    g_game.add_argument("--judge_height", type=float, default=0.06, help="Judgement height as ratio of screen height")
    g_game.add_argument("--flick_threshold", type=float, default=0.02, help="Flick gesture threshold as ratio of screen width")
    g_game.add_argument("--start_time", type=float, default=None, help="Start time in seconds (cuts chart before this time)")
    g_game.add_argument("--end_time", type=float, default=None, help="End time in seconds (cuts chart after this time)")

    g_ui = ap.add_argument_group("UI")
    g_ui.add_argument("--no_title_overlay", action="store_true")
    g_ui.add_argument("--advance_seq_overlay", action="store_true")
    g_ui.add_argument("--font_path", type=str, default=None)
    g_ui.add_argument("--font_size_multiplier", type=float, default=1.0)

    g_ui.add_argument("--advance_lazy_load", action="store_true")
    g_ui.add_argument("--advance_lazy_cache", type=int, default=1)
    g_ui.add_argument("--advance_lazy_preload", action="store_true")
    g_ui.add_argument("--advance_lazy_scan_total_notes", action="store_true")

    g_rpe = ap.add_argument_group("RPE")
    g_rpe.add_argument("--rpe_easing_shift", type=int, default=0)

    g_dbg = ap.add_argument_group("Debug")
    g_dbg.add_argument("--basic_debug", action="store_true")
    g_dbg.add_argument("--debug_line_label", action="store_true")
    g_dbg.add_argument("--debug_line_stats", action="store_true")
    g_dbg.add_argument("--debug_judge_windows", action="store_true")
    g_dbg.add_argument("--debug_pointer", action="store_true")
    g_dbg.add_argument("--debug_note_info", action="store_true")
    g_dbg.add_argument("--debug_particles", action="store_true")
    g_dbg.add_argument("--hit_debug", action="store_true")

    g_gui = ap.add_argument_group("GUI")
    g_gui.add_argument("--gui", action="store_true", help="Open Qt launcher UI (optional; requires PySide6 or PyQt6)")

    g_pcc = ap.add_argument_group("PCC")
    g_pcc.add_argument("--export_pcc", type=str, default=None, help="Export input chart/pack to PCC file and exit")
    g_pcc.add_argument("--export_pcc_password", type=str, default=None, help="Optional password to encrypt exported PCC")
    g_pcc.add_argument("--export_pcc_no_compress", action="store_true", help="Disable compression when exporting PCC")

    return ap


def run_from_args(args: Any, *, argv_tokens: Optional[list[str]] = None) -> None:
    global respack  # Declare we're using the global variable

    logger = logging.getLogger(__name__)

    if argv_tokens is None:
        try:
            argv_tokens = list(sys.argv[1:])
        except Exception:
            argv_tokens = []

    if bool(getattr(args, "gui", False)):
        try:
            from .gui.qt_launcher import run_gui  # type: ignore

            run_gui()
            return
        except Exception as e:
            raise SystemExit(f"Failed to start GUI launcher: {e}")


    if getattr(args, "playlist_script", None):
        raise SystemExit("playlist mode is preparing; please use --advance with a generated advance JSON for now")

    setup_logging(args)
    logger.debug("CLI args parsed")

    try:
        setattr(state, "_sigint", False)
    except:
        pass
    try:
        def _on_sigint(_signum, _frame):
            try:
                setattr(state, "_sigint", True)
            except:
                pass
        _old_sigint = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, _on_sigint)
    except:
        _old_sigint = None

    cfg_mods: Optional[Dict[str, Any]] = None

    if (not args.input) and (not args.advance) and (not getattr(args, "playlist_script", None)):
        raise SystemExit("Either --input or --advance or --playlist_script must be provided")

    cfg_v2_raw: Optional[Dict[str, Any]] = None
    if args.config:
        try:
            cfg_v2_raw = load_config_v2(str(args.config))
            flat_cfg, mods_cfg = flatten_config_v2(cfg_v2_raw)
            cfg_mods = mods_cfg
            for k, v in (flat_cfg or {}).items():
                if not hasattr(args, k):
                    continue
                if ("--" + k) in argv_tokens:
                    continue
                setattr(args, k, v)
        except:
            pass

    # language: CLI overrides config ui.lang
    lang = getattr(args, "lang", None)
    if not lang:
        lang = pick_lang_from_config(cfg_v2_raw)
    lang = normalize_lang(lang)

    if args.config_old:
        try:
            with open(str(args.config_old), "r", encoding="utf-8") as f:
                cfg_old = json.load(f)
            if isinstance(cfg_old, dict):
                cfg_mods = cfg_old.get("mods")
            for k, v in (cfg_old or {}).items():
                if not hasattr(args, k):
                    continue
                if ("--" + k) in argv_tokens:
                    continue
                setattr(args, k, v)
        except:
            pass

    if bool(getattr(args, "simulateplay", False)):
        try:
            setattr(args, "autoplay", False)
        except Exception:
            pass

    if bool(getattr(args, "simulateplay_ipad", False)):
        if not bool(getattr(args, "simulateplay", False)):
            try:
                setattr(args, "simulateplay", True)
            except Exception:
                pass
        if not getattr(args, "ipad_bundle_id", None):
            raise SystemExit("--simulateplay_ipad requires --ipad_bundle_id")

    if args.save_config:
        try:
            with open(args.save_config, "w", encoding="utf-8") as f:
                f.write(dump_config_v2(args, mods=cfg_mods, lang=lang))
        except:
            pass

    def _c(s: str, code: str) -> str:
        if bool(getattr(args, "no_color", False)):
            return s
        return f"\x1b[{code}m{s}\x1b[0m"

    def _kv(k: str, v: Any) -> str:
        if v is None:
            v = tr(lang, "cui.value.none", "(none)")
        return f"{_c(k, '1;36')}: {v}"

    if not bool(getattr(args, "quiet", False)):
        title = tr(lang, "cui.title", "Mini Phigros Renderer")
        logger.info(title)
        if getattr(args, "config", None):
            logger.info(_kv(tr(lang, "cui.config", "Config"), str(getattr(args, "config"))))
        elif getattr(args, "config_old", None):
            logger.info(_kv(tr(lang, "cui.config", "Config"), str(getattr(args, "config_old"))))
        logger.info(_kv(tr(lang, "cui.input", "Input"), getattr(args, "input", None) or getattr(args, "advance", None)))
        logger.info(_kv(tr(lang, "cui.window", "Window"), f"{int(args.w)}x{int(args.h)}"))
        logger.info(_kv(tr(lang, "cui.backend", "Backend"), f"{getattr(args, 'backend', None)} / {getattr(args, 'audio_backend', None)}"))
        logger.info(_kv(tr(lang, "cui.assets", "Assets"), f"respack={getattr(args, 'respack', None)} bg={getattr(args, 'bg', None)}"))
        logger.info(_kv(tr(lang, "cui.render", "Render"), f"speed={getattr(args, 'chart_speed', None)} approach={getattr(args, 'approach', None)} expand={getattr(args, 'expand', None)}"))
        ap_on = tr(lang, "cui.on", "on") if bool(getattr(args, "autoplay", False)) else tr(lang, "cui.off", "off")
        logger.info(_kv(tr(lang, "cui.autoplay", "Autoplay"), ap_on))
        logger.info(_kv(tr(lang, "cui.start_end", "Start/End"), f"{getattr(args, 'start_time', None)} .. {getattr(args, 'end_time', None)}"))
        logger.info(tr(lang, "cui.help.hint", "Tip: --save_config writes a commented config template."))

    W, H = args.w, args.h
    expand = float(args.expand) if args.expand is not None else 1.0
    if expand <= 1.000001:
        expand = 1.0

    # PCC export mode: resolve input and export, then exit.
    if getattr(args, "export_pcc", None):
        if not getattr(args, "input", None):
            raise SystemExit("--export_pcc requires --input")
        if getattr(args, "advance", None):
            raise SystemExit("--export_pcc does not support --advance")
        try:
            from .pcc.exporter import export_input_to_pcc

            out_path = str(getattr(args, "export_pcc"))
            pw = getattr(args, "export_pcc_password", None)
            compress = (not bool(getattr(args, "export_pcc_no_compress", False)))
            fmt_i, off_i, lc, nc = export_input_to_pcc(
                str(getattr(args, "input")),
                out_path,
                W=int(W),
                H=int(H),
                password=str(pw) if pw else None,
                compress=bool(compress),
            )
            logger.info("[PCC] Exported fmt=%s offset=%.4f lines=%d notes=%d -> %s", str(fmt_i), float(off_i), int(lc), int(nc), str(out_path))
            return
        except Exception as e:
            raise SystemExit(f"PCC export failed: {e}")

    # Visibility checks (shared across modules)
    state.expand_factor = expand

    try:
        state.note_flow_speed_multiplier = float(getattr(args, "note_flow_speed_multiplier", 1.0) or 1.0)
    except:
        state.note_flow_speed_multiplier = 1.0

    try:
        state.note_scale_x = float(getattr(args, "note_scale_x", 1.0) or 1.0)
        state.note_scale_y = float(getattr(args, "note_scale_y", 1.0) or 1.0)
    except:
        state.note_scale_x = 1.0
        state.note_scale_y = 1.0

    # RPE easingType shift (some exporters are 1-based)
    easing.set_rpe_easing_shift(int(args.rpe_easing_shift))

    if getattr(args, "playlist_script", None):
        run_playlist_script(args)
        return

    adv = load_from_args(args, W, H)

    fmt = adv.fmt
    offset = adv.offset
    lines = adv.lines
    notes = adv.notes
    advance_active = adv.advance_active
    advance_cfg = adv.advance_cfg
    advance_mix = adv.advance_mix
    advance_tracks_bgm = adv.advance_tracks_bgm
    advance_main_bgm = adv.advance_main_bgm
    advance_segment_starts = adv.advance_segment_starts
    advance_segment_bgm = adv.advance_segment_bgm
    advance_base_dir = adv.advance_base_dir
    advance_mods = adv.advance_mods
    chart_path = adv.chart_path
    chart_info = adv.chart_info
    bg_path = adv.bg_path
    music_path = adv.music_path
    bg_dim_alpha = adv.bg_dim_alpha

    mods_cfg: Dict[str, Any] = {}
    if isinstance(cfg_mods, dict):
        mods_cfg.update(cfg_mods)
    if advance_active and advance_cfg is not None and isinstance(locals().get("advance_mods"), dict):
        mods_cfg.update(locals()["advance_mods"])

    try:
        setattr(args, "_mods_cfg", dict(mods_cfg))
    except Exception:
        pass

    notes = apply_mods(mods_cfg, notes, lines)

    try:
        run_renderer(
            args,
            W=W,
            H=H,
            expand=expand,
            fmt=fmt,
            offset=offset,
            lines=lines,
            notes=notes,
            chart_info=chart_info,
            bg_dim_alpha=bg_dim_alpha,
            bg_path=bg_path,
            music_path=music_path,
            chart_path=chart_path,
            advance_active=advance_active,
            advance_cfg=advance_cfg,
            advance_mix=advance_mix,
            advance_tracks_bgm=advance_tracks_bgm,
            advance_main_bgm=advance_main_bgm,
            advance_segment_starts=advance_segment_starts,
            advance_segment_bgm=advance_segment_bgm,
            advance_base_dir=advance_base_dir,
        )
    except KeyboardInterrupt:
        try:
            logger.info("[phic_renderer] Interrupted")
        except:
            pass
    finally:
        if _old_sigint is not None:
            try:
                signal.signal(signal.SIGINT, _old_sigint)
            except:
                pass


def main(argv: Optional[list[str]] = None) -> None:
    ap = build_arg_parser()
    argv_tokens = list(sys.argv[1:]) if argv is None else list(argv)
    args = ap.parse_args(argv_tokens)
    run_from_args(args, argv_tokens=argv_tokens)

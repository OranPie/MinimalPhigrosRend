from __future__ import annotations

import argparse
import os
import signal
import sys
import tempfile
import logging
import threading
from typing import Any, Dict, Optional

from . import state
from .config_v2 import flatten_config_v2, load_config_v2
from .engine.advance import load_from_args
from .engine.mods import apply_mods
from .renderer import run as run_renderer
from .recording.frame_recorder import FrameRecorder
from .recording.video_recorder import VideoRecorder, check_ffmpeg
from .recording.audio_mixer import mix_wav
from .assets.respack import load_respack_info
from .recording.presets import list_presets
from .logging_setup import setup_logging
from .ui.headless.textual import init_textual_ui
from .api.playlist import load_playlist_script, run_playlist_script, build_chart_metas


def main():
    logger = logging.getLogger(__name__)
    ap = argparse.ArgumentParser(prog="phic_renderer.record")

    g_in = ap.add_argument_group("Input")
    g_in.add_argument("--input", required=False, default=None, help="chart.json OR chart pack folder OR .zip/.pez pack")
    g_in.add_argument("--advance", type=str, default=None)
    g_in.add_argument("--playlist_script", type=str, default=None, help="Run a playlist script (python file)")
    g_in.add_argument("--playlist_charts_dir", type=str, default="charts")
    g_in.add_argument("--playlist_notes_per_chart", type=int, default=10)
    g_in.add_argument("--playlist_tail_time", type=float, default=0.5)
    g_in.add_argument("--playlist_seed", type=int, default=None)
    g_in.add_argument("--playlist_no_shuffle", action="store_true")
    g_in.add_argument("--playlist_switch_mode", type=str, default="hit", choices=["hit", "judged"])
    g_in.add_argument("--playlist_filter_levels", type=str, default=None)
    g_in.add_argument("--playlist_filter_name_contains", type=str, default=None)
    g_in.add_argument("--playlist_filter_min_total_notes", type=int, default=None)
    g_in.add_argument("--playlist_filter_max_total_notes", type=int, default=None)
    g_in.add_argument("--playlist_filter_limit", type=int, default=None)
    g_in.add_argument("--playlist_start_mode", type=str, default="fresh", choices=["fresh", "resume"])
    g_in.add_argument("--playlist_start_index", type=int, default=None)
    g_in.add_argument("--playlist_start_from_hit_total", type=int, default=None)
    g_in.add_argument("--playlist_start_from_combo_total", type=int, default=None)

    g_cfg = ap.add_argument_group("Config")
    g_cfg.add_argument("--config", type=str, required=True, help="Config v2 (JSONC) path")

    g_rec = ap.add_argument_group("Record")
    g_rec.add_argument("--out_dir", type=str, default=None, help="Output directory for frame_XXXXXX.png (frames mode)")
    g_rec.add_argument("--output", type=str, default=None, help="Output video file path (video/video+audio modes)")
    g_rec.add_argument("--mode", type=str, default="video+audio", choices=["frames", "video", "video+audio"],
                      help="Recording mode: frames (PNG sequence), video (MP4 no audio), video+audio (MP4 with audio)")
    g_rec.add_argument("--preset", type=str, default="balanced", choices=list_presets(),
                      help="Encoding preset: fast, balanced, quality, archive")
    g_rec.add_argument("--codec", type=str, default="libx264", help="Video codec (libx264, libx265, libvpx-vp9)")
    g_rec.add_argument("--fps", type=float, default=60.0)
    g_rec.add_argument("--start_time", type=float, default=0.0)
    g_rec.add_argument("--end_time", type=float, default=None)
    g_rec.add_argument("--duration", type=float, default=None, help="Seconds to record (alternative to --end_time)")
    g_rec.add_argument("--headless", action="store_true", help="Do not open a window; render as fast as possible with CLI progress")
    g_rec.add_argument("--log_interval", type=float, default=1.0, help="Seconds between CLI incoming/past logs (0 disables)")
    g_rec.add_argument("--log_notes", action="store_true", help="Log incoming/past note counts periodically")
    g_rec.add_argument("--no_hitsound", action="store_true", help="Do not include hitsounds in video audio track")
    g_rec.add_argument(
        "--ui",
        type=str,
        default="textual",
        choices=["textual", "curses", "none"],
        help="Headless UI backend: textual (recommended), curses (legacy), none",
    )
    g_rec.add_argument("--advance_seq_overlay", action="store_true")
    g_rec.add_argument("--advance_lazy_load", action="store_true")
    g_rec.add_argument("--advance_lazy_cache", type=int, default=1)
    g_rec.add_argument("--advance_lazy_preload", action="store_true")
    g_rec.add_argument("--advance_lazy_scan_total_notes", action="store_true")
    g_rec.add_argument("--no_curses", action="store_true", help="Disable curses CUI in headless mode")
    g_rec.add_argument("--curses_fps", type=float, default=10.0, help="Headless curses refresh rate")
    g_rec.add_argument("--no_particles", action="store_true", help="Do not render particles into recorded frames")
    g_rec.add_argument("--no_text", action="store_true", help="Do not render text overlays into recorded frames")
    g_rec.add_argument("--hit_debug", action="store_true", help="Show recent hit debug info overlay")
    g_rec.add_argument("--judge_script", type=str, default=None, help="Optional judge script JSON to simulate non-perfect autoplay")

    args = ap.parse_args()

    if getattr(args, "playlist_script", None):
        raise SystemExit("playlist mode is preparing; please use --advance with a generated advance JSON for now")

    setup_logging(args)
    logger.debug("record CLI args parsed")

    try:
        setattr(state, "_sigint", False)
    except:
        pass
    try:
        def _on_sigint(_signum, _frame):
            try:
                setattr(state, "_sigint", True)
            except:
                pass
        _old_sigint = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, _on_sigint)
    except:
        _old_sigint = None

    # Determine recording mode and validate arguments
    mode = str(args.mode)
    rec_fps = float(args.fps)
    rec_start_time = float(args.start_time)
    rec_end_time = float(args.end_time) if args.end_time is not None else None
    rec_duration = float(args.duration) if args.duration is not None else None
    rec_headless = bool(getattr(args, "headless", False))
    rec_log_interval = float(getattr(args, "log_interval", 1.0) or 0.0)
    rec_log_notes = bool(getattr(args, "log_notes", False))

    if rec_end_time is not None and rec_duration is not None:
        raise SystemExit("Use only one of --end_time or --duration")
    if rec_duration is not None and rec_duration <= 0.0:
        raise SystemExit("--duration must be > 0")
    if rec_end_time is not None and rec_end_time <= rec_start_time:
        raise SystemExit("--end_time must be greater than --start_time")

    # Validate output arguments based on mode
    if mode == "frames":
        if not args.out_dir:
            raise SystemExit("--out_dir is required for frames mode")
        rec_out_dir = str(args.out_dir)
    else:
        if not args.output:
            raise SystemExit("--output is required for video/video+audio modes")
        rec_output = str(args.output)

    if (not args.input) and (not args.advance) and (not getattr(args, "playlist_script", None)):
        raise SystemExit("Either --input or --advance or --playlist_script must be provided")

    cfg_v2_raw: Optional[Dict[str, Any]] = None
    try:
        cfg_v2_raw = load_config_v2(str(args.config))
    except Exception as e:
        logger.exception("Failed to load config: %s", args.config)
        raise SystemExit(f"Failed to load config: {args.config} ({e})")

    flat_cfg, mods_cfg = flatten_config_v2(cfg_v2_raw)

    # Apply config values, but do not override explicit CLI args.
    # (Keep behavior consistent with phic_renderer/app.py.)
    argv_l = list(getattr(sys, "argv", []) or [])
    for k, v in (flat_cfg or {}).items():
        try:
            if not hasattr(args, k):
                continue
            if ("--" + str(k)) in argv_l:
                continue
            setattr(args, k, v)
        except Exception:
            continue

    if getattr(args, "judge_script", None):
        try:
            setattr(args, "judge_script", str(getattr(args, "judge_script")))
        except:
            pass

    # Remove line that forces pygame backend - allow moderngl recording in future
    # setattr(args, "backend", "pygame")

    W = int(getattr(args, "w", 1280) or 1280)
    H = int(getattr(args, "h", 720) or 720)

    expand = float(getattr(args, "expand", 1.0) or 1.0)
    if expand <= 1.000001:
        expand = 1.0

    state.expand_factor = float(expand)

    adv = None
    fmt = None
    offset = 0.0
    lines = None
    notes = None

    if not getattr(args, "playlist_script", None):
        adv = load_from_args(args, W, H)

        fmt = adv.fmt
        offset = adv.offset
        lines = adv.lines
        notes = adv.notes

    # Ensure recording has a finite stop time.
    # For playlist_script, user must provide a finite stop via playlist switch/jump/stop.
    if rec_end_time is None and (not getattr(args, "playlist_script", None)):
        if rec_duration is not None:
            rec_end_time = float(rec_start_time) + float(rec_duration)
        else:
            try:
                chart_end = max((float(getattr(n, "t_end", 0.0) or 0.0) for n in notes if not getattr(n, "fake", False)), default=0.0)
            except:
                chart_end = 0.0
            if chart_end <= 1e-6:
                # Fallback: avoid infinite recording even if chart_end is missing
                chart_end = 30.0
            rec_end_time = max(float(rec_start_time), float(chart_end))

    mods_cfg_out: Dict[str, Any] = {}
    if isinstance(mods_cfg, dict):
        mods_cfg_out.update(mods_cfg)
    if adv is not None and adv.advance_active and isinstance(adv.advance_mods, dict):
        mods_cfg_out.update(adv.advance_mods)

    try:
        setattr(args, "_mods_cfg", dict(mods_cfg_out))
    except Exception:
        pass

    if adv is not None:
        notes = apply_mods(mods_cfg_out, notes, lines)

    audio_path: Optional[str] = None
    audio_temp_fd: Optional[int] = None
    audio_temp_keep: Optional[str] = None
    respack_tmpdir = None

    if mode in ["video", "video+audio"]:
        if not check_ffmpeg():
            raise SystemExit("ERROR: ffmpeg not found. Please install ffmpeg for video recording.\n"
                           "Install: https://ffmpeg.org/download.html")

        if mode == "video+audio" and (not getattr(args, "playlist_script", None)):
            try:
                duration = max(0.0, float(rec_end_time) - float(rec_start_time))
                if duration <= 1e-6:
                    raise RuntimeError("Invalid recording duration")

                bgm_tracks = []
                bgm_vol = float(getattr(args, "bgm_volume", 0.8) or 0.8)

                if adv.advance_active:
                    if adv.advance_tracks_bgm:
                        for tr in adv.advance_tracks_bgm:
                            p = str(tr.get("path") or "")
                            if not p or (not os.path.exists(p)):
                                continue
                            st = float(tr.get("start_at", 0.0) or 0.0)
                            en = tr.get("end_at", None)
                            en = float(en) if en is not None else None

                            seg_start = max(float(rec_start_time), st)
                            seg_end = float(rec_end_time) if en is None else min(float(rec_end_time), float(en))
                            seg_dur = max(0.0, seg_end - seg_start)
                            if seg_dur <= 1e-6:
                                continue

                            start_at_out = seg_start - float(rec_start_time)
                            ss = max(0.0, float(rec_start_time) - st)
                            bgm_tracks.append((p, start_at_out, seg_dur, bgm_vol, ss))
                    elif adv.advance_segment_bgm and adv.advance_segment_starts:
                        starts = list(adv.advance_segment_starts)
                        for i, p in enumerate(list(adv.advance_segment_bgm)):
                            if not p:
                                continue
                            pth = str(p)
                            if not os.path.exists(pth):
                                continue
                            st = float(starts[i]) if i < len(starts) else 0.0
                            nxt = float(starts[i + 1]) if (i + 1) < len(starts) else float(rec_end_time)

                            seg_start = max(float(rec_start_time), st)
                            seg_end = min(float(rec_end_time), nxt)
                            seg_dur = max(0.0, seg_end - seg_start)
                            if seg_dur <= 1e-6:
                                continue
                            start_at_out = seg_start - float(rec_start_time)
                            ss = max(0.0, float(rec_start_time) - st)
                            bgm_tracks.append((pth, start_at_out, seg_dur, bgm_vol, ss))
                else:
                    music_path = None
                    if bool(getattr(args, "force", False)) and getattr(args, "bgm", None):
                        music_path = str(getattr(args, "bgm"))
                    elif adv.music_path and os.path.exists(str(adv.music_path)):
                        music_path = str(adv.music_path)
                    elif getattr(args, "bgm", None):
                        music_path = str(getattr(args, "bgm"))

                    if music_path and os.path.exists(music_path):
                        chart_speed = float(getattr(args, "chart_speed", 1.0) or 1.0)
                        if chart_speed <= 1e-9:
                            chart_speed = 1.0
                        ss0 = float(adv.offset) + float(rec_start_time) / float(chart_speed)
                        bgm_tracks.append((
                            str(music_path),
                            0.0,
                            float(rec_end_time) - float(rec_start_time),
                            bgm_vol,
                            max(0.0, ss0),
                        ))

                hitsound_events = []
                include_hitsound = not bool(getattr(args, "no_hitsound", False))
                if include_hitsound:
                    respack_zip = getattr(args, "respack", None)
                    respack_sfx = {}
                    if respack_zip and os.path.exists(str(respack_zip)):
                        respack_tmpdir, _info = load_respack_info(str(respack_zip))
                        base = str(getattr(respack_tmpdir, "name", ""))
                        if base:
                            cand = {
                                "click": os.path.join(base, "click.ogg"),
                                "drag": os.path.join(base, "drag.ogg"),
                                "flick": os.path.join(base, "flick.ogg"),
                            }
                            for k, fp in cand.items():
                                if os.path.exists(fp):
                                    respack_sfx[k] = fp

                    for n in notes:
                        if getattr(n, "fake", False):
                            continue
                        t = float(getattr(n, "t_hit", 0.0) or 0.0)
                        t_out = t - float(rec_start_time)
                        if t_out < 0.0 or t_out >= float(duration):
                            continue

                        pth = None
                        hs = getattr(n, "hitsound_path", None)
                        if hs and os.path.exists(str(hs)):
                            pth = str(hs)
                        else:
                            kind = int(getattr(n, "kind", 1) or 1)
                            key = "click"
                            if kind == 2:
                                key = "drag"
                            elif kind == 4:
                                key = "flick"
                            pth = respack_sfx.get(key)
                        if pth:
                            hitsound_events.append((pth, t_out, 1.0))

                audio_temp_fd, audio_temp_keep = tempfile.mkstemp(suffix='.wav', prefix='phigros_mix_')
                os.close(audio_temp_fd)
                audio_path = mix_wav(
                    out_wav_path=audio_temp_keep,
                    duration=duration,
                    bgm_tracks=bgm_tracks,
                    hitsound_events=hitsound_events,
                )
                logger.info("[Recording] Audio: Mixed")
            except Exception as e:
                logger.exception("[Recording] Failed to prepare audio")
                logger.warning("[Recording] Falling back to video-only mode")
                audio_path = None

        if mode == "video+audio" and bool(getattr(args, "playlist_script", None)):
            try:
                W0 = int(W)
                H0 = int(H)

                charts_dir = str(getattr(args, "playlist_charts_dir", getattr(args, "charts_dir", "charts")) or "charts")
                notes_per_chart = int(getattr(args, "playlist_notes_per_chart", 10) or 10)
                tail_time = float(getattr(args, "playlist_tail_time", 0.0) or 0.0)

                mod = load_playlist_script(str(getattr(args, "playlist_script")))

                if hasattr(mod, "configure_args") and callable(getattr(mod, "configure_args")):
                    try:
                        getattr(mod, "configure_args")(args)
                    except Exception:
                        pass

                metas = None
                if hasattr(mod, "build_metas") and callable(getattr(mod, "build_metas")):
                    try:
                        metas = list(getattr(mod, "build_metas")(args) or [])
                    except Exception:
                        metas = None
                if metas is None:
                    metas = build_chart_metas(
                        charts_dir=str(charts_dir),
                        W=int(W0),
                        H=int(H0),
                        notes_per_chart=int(notes_per_chart),
                        tail_time=float(tail_time),
                        seed=getattr(args, "playlist_seed", None),
                        shuffle=(not bool(getattr(args, "playlist_no_shuffle", False))),
                        filter_levels=None,
                        filter_name_contains=getattr(args, "playlist_filter_name_contains", None),
                        filter_min_total_notes=getattr(args, "playlist_filter_min_total_notes", None),
                        filter_max_total_notes=getattr(args, "playlist_filter_max_total_notes", None),
                        filter_limit=getattr(args, "playlist_filter_limit", None),
                        filter_fn=(getattr(args, "playlist_filter", None) if callable(getattr(args, "playlist_filter", None)) else None),
                    )

                if not metas:
                    raise RuntimeError("No playable charts found for playlist")

                try:
                    setattr(args, "_playlist_metas_cache", list(metas))
                except Exception:
                    pass

                from .assets.loader import load_chart

                total_duration = float(sum(float(getattr(m, "seg_duration", 0.0) or 0.0) for m in metas))
                if total_duration <= 1e-6:
                    raise RuntimeError("Invalid playlist duration")

                bgm_tracks = []
                bgm_vol = float(getattr(args, "bgm_volume", 0.8) or 0.8)
                chart_speed = float(getattr(args, "chart_speed", 1.0) or 1.0)
                if chart_speed <= 1e-9:
                    chart_speed = 1.0

                include_hitsound = not bool(getattr(args, "no_hitsound", False))
                hitsound_events = []

                respack_zip = getattr(args, "respack", None)
                respack_sfx = {}
                if include_hitsound and respack_zip and os.path.exists(str(respack_zip)):
                    respack_tmpdir, _info = load_respack_info(str(respack_zip))
                    base = str(getattr(respack_tmpdir, "name", ""))
                    if base:
                        cand = {
                            "click": os.path.join(base, "click.ogg"),
                            "drag": os.path.join(base, "drag.ogg"),
                            "flick": os.path.join(base, "flick.ogg"),
                        }
                        for k, fp in cand.items():
                            if os.path.exists(fp):
                                respack_sfx[k] = fp

                t0_playlist = 0.0
                for meta in metas:
                    seg_dur = float(getattr(meta, "seg_duration", 0.0) or 0.0)
                    if seg_dur <= 1e-6:
                        continue

                    music_path = getattr(meta, "music_path", None)
                    if music_path and os.path.exists(str(music_path)):
                        ss0 = float(getattr(meta, "chart_offset", 0.0) or 0.0) + 0.0 / float(chart_speed)
                        bgm_tracks.append((
                            str(music_path),
                            float(t0_playlist),
                            float(seg_dur),
                            float(bgm_vol),
                            max(0.0, float(ss0)),
                        ))

                    if include_hitsound:
                        try:
                            _fmt, _off, _lines, notes = load_chart(str(getattr(meta, "chart_path")), int(W0), int(H0))
                        except Exception:
                            notes = []
                        playable = [n for n in notes if not getattr(n, "fake", False)]
                        try:
                            playable.sort(key=lambda x: float(getattr(x, "t_hit", 0.0) or 0.0))
                        except Exception:
                            pass
                        seg_notes = int(getattr(meta, "seg_notes", 0) or 0)
                        if seg_notes > 0:
                            playable = playable[:seg_notes]

                        chart_dir = os.path.dirname(os.path.abspath(str(getattr(meta, "chart_path"))))
                        for n in playable:
                            try:
                                t_hit = float(getattr(n, "t_hit", 0.0) or 0.0)
                            except Exception:
                                continue
                            t_out = float(t0_playlist) + float(t_hit)
                            if t_out < 0.0 or t_out >= float(total_duration):
                                continue

                            pth = None
                            hs = getattr(n, "hitsound_path", None)
                            if hs:
                                try:
                                    if os.path.isabs(str(hs)) and os.path.exists(str(hs)):
                                        pth = str(hs)
                                    else:
                                        cand = os.path.join(str(chart_dir), str(hs))
                                        if os.path.exists(cand):
                                            pth = cand
                                except Exception:
                                    pth = None

                            if not pth:
                                try:
                                    kind = int(getattr(n, "kind", 1) or 1)
                                except Exception:
                                    kind = 1
                                key = "click"
                                if kind == 2:
                                    key = "drag"
                                elif kind == 4:
                                    key = "flick"
                                pth = respack_sfx.get(key)

                            if pth:
                                hitsound_events.append((str(pth), float(t_out), 1.0))

                    t0_playlist += float(seg_dur)

                audio_temp_fd, audio_temp_keep = tempfile.mkstemp(suffix='.wav', prefix='phigros_playlist_mix_')
                os.close(audio_temp_fd)
                audio_path = mix_wav(
                    out_wav_path=audio_temp_keep,
                    duration=float(total_duration),
                    bgm_tracks=bgm_tracks,
                    hitsound_events=hitsound_events,
                )
                logger.info("[Recording] Audio: Mixed (playlist)")
            except Exception:
                logger.exception("[Recording] Failed to prepare playlist audio")
                logger.warning("[Recording] Falling back to video-only mode")
                audio_path = None

        recorder = VideoRecorder(
            output_file=rec_output,
            width=W,
            height=H,
            fps=rec_fps,
            preset=args.preset,
            audio_path=audio_path,
            codec=args.codec
        )

        logger.info("[Recording] Mode: %s → %s", "Video+Audio" if audio_path else "Video-only", rec_output)
        logger.info("[Recording] Resolution: %sx%s @ %sfps", W, H, rec_fps)
        logger.info("[Recording] Preset: %s (codec: %s)", args.preset, args.codec)

    else:
        recorder = None
        if mode == "frames":
            try:
                os.makedirs(rec_out_dir, exist_ok=True)
            except Exception as e:
                raise SystemExit(f"Cannot create output directory: {rec_out_dir} ({e})")

            recorder = FrameRecorder(rec_out_dir, W, H, rec_fps)
            logger.info("[Recording] Mode: PNG frames → %s", rec_out_dir)
            logger.info("[Recording] Resolution: %sx%s @ %sfps", W, H, rec_fps)

    if recorder:
        try:
            recorder.open()
            logger.info("[Recording] Recorder initialized successfully")
        except Exception as e:
            raise SystemExit(f"Failed to initialize recorder: {e}")

    setattr(args, "recorder", recorder)

    setattr(args, "record_enabled", True)
    setattr(args, "record_fps", rec_fps)
    setattr(args, "record_start_time", rec_start_time)
    setattr(args, "record_end_time", rec_end_time)
    setattr(args, "record_headless", rec_headless)
    setattr(args, "record_log_interval", rec_log_interval)
    setattr(args, "record_log_notes", rec_log_notes)
    ui = str(getattr(args, "ui", "textual") or "textual")
    if not rec_headless:
        ui = "none"

    use_curses = (ui == "curses") and (not bool(getattr(args, "no_curses", False))) and rec_headless
    use_textual = (ui == "textual") and rec_headless

    setattr(args, "record_use_curses", bool(use_curses))
    setattr(args, "record_use_textual", bool(use_textual))
    setattr(args, "record_curses_fps", float(getattr(args, "curses_fps", 10.0) or 10.0))
    setattr(args, "record_render_particles", (not bool(getattr(args, "no_particles", False))))
    setattr(args, "record_render_text", (not bool(getattr(args, "no_text", False))))

    if bool(getattr(args, "hit_debug", False)):
        setattr(args, "hit_debug", True)

    interrupted = False
    try:
        if bool(getattr(args, "record_headless", False)) and bool(getattr(args, "record_use_textual", False)):
            ok, tui, err = init_textual_ui(refresh_hz=float(getattr(args, "record_curses_fps", 10.0) or 10.0))
            if not ok or tui is None:
                raise SystemExit(f"Textual UI requested but failed to start: {err}")

            setattr(args, "textual_ui", tui)

            def _run_renderer_worker():
                nonlocal interrupted
                try:
                    if getattr(args, "playlist_script", None):
                        run_playlist_script(args)
                    else:
                        run_renderer(
                            args,
                            W=W,
                            H=H,
                            expand=expand,
                            fmt=fmt,
                            offset=offset,
                            lines=lines,
                            notes=notes,
                            chart_info=adv.chart_info,
                            bg_dim_alpha=adv.bg_dim_alpha,
                            bg_path=adv.bg_path,
                            music_path=adv.music_path,
                            chart_path=adv.chart_path,
                            advance_active=adv.advance_active,
                            advance_cfg=adv.advance_cfg,
                            advance_mix=adv.advance_mix,
                            advance_tracks_bgm=adv.advance_tracks_bgm,
                            advance_main_bgm=adv.advance_main_bgm,
                            advance_segment_starts=adv.advance_segment_starts,
                            advance_segment_bgm=adv.advance_segment_bgm,
                            advance_base_dir=adv.advance_base_dir,
                        )
                except KeyboardInterrupt:
                    interrupted = True
                except Exception:
                    logger.exception("Renderer worker failed")
                finally:
                    try:
                        tui.stop()
                    except Exception:
                        pass

            th = threading.Thread(target=_run_renderer_worker, daemon=True)
            th.start()

            try:
                tui.run()
            finally:
                try:
                    setattr(state, "_sigint", True)
                except Exception:
                    pass
                try:
                    tui.stop()
                except Exception:
                    pass
                try:
                    th.join(timeout=2.0)
                except Exception:
                    pass
        else:
            try:
                if getattr(args, "playlist_script", None):
                    run_playlist_script(args)
                else:
                    run_renderer(
                        args,
                        W=W,
                        H=H,
                        expand=expand,
                        fmt=fmt,
                        offset=offset,
                        lines=lines,
                        notes=notes,
                        chart_info=adv.chart_info,
                        bg_dim_alpha=adv.bg_dim_alpha,
                        bg_path=adv.bg_path,
                        music_path=adv.music_path,
                        chart_path=adv.chart_path,
                        advance_active=adv.advance_active,
                        advance_cfg=adv.advance_cfg,
                        advance_mix=adv.advance_mix,
                        advance_tracks_bgm=adv.advance_tracks_bgm,
                        advance_main_bgm=adv.advance_main_bgm,
                        advance_segment_starts=adv.advance_segment_starts,
                        advance_segment_bgm=adv.advance_segment_bgm,
                        advance_base_dir=adv.advance_base_dir,
                    )
            except KeyboardInterrupt:
                interrupted = True
            except Exception:
                logger.exception("Renderer worker failed")
    finally:
        if recorder:
            try:
                recorder.close()
                logger.info("[Recording] Finalized successfully")
            except Exception:
                logger.exception("[Recording] Failed to finalize")

        if interrupted:
            try:
                logger.info("[Recording] Interrupted")
            except:
                pass

        if _old_sigint is not None:
            try:
                signal.signal(signal.SIGINT, _old_sigint)
            except:
                pass

        if respack_tmpdir is not None:
            try:
                respack_tmpdir.cleanup()
            except:
                pass

        if audio_temp_keep is not None and os.path.exists(str(audio_temp_keep)):
            try:
                os.remove(str(audio_temp_keep))
            except:
                pass


if __name__ == "__main__":
    main()

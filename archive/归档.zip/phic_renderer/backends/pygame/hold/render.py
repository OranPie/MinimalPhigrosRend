from __future__ import annotations

import math
from typing import Optional, Tuple

import pygame

from .... import state
from ....math.util import clamp
from ..rendering.draw import draw_poly_outline_rgba
from ..performance.surface_pool import get_global_pool
from .cache import get_global_hold_cache


def draw_hold_3slice(
    overlay: pygame.Surface,
    head_xy: Tuple[float, float],
    tail_xy: Tuple[float, float],
    line_rot: float,
    alpha01: float,
    line_rgb: Tuple[int, int, int],
    note_rgb: Tuple[int, int, int],
    size_scale: float,
    mh: bool,
    hold_body_w: int,
    progress: Optional[float] = None,
    draw_outline: bool = True,
    outline_width: int = 2,
):
    rp = state.respack
    respack = rp
    if not respack:
        return

    a = int(255 * clamp(alpha01, 0.0, 1.0))

    img_key = "hold_mh.png" if mh else "hold.png"
    img = respack.img[img_key]
    iw, ih = img.get_width(), img.get_height()

    tail_h = respack.hold_tail_h_mh if mh else respack.hold_tail_h
    head_h = respack.hold_head_h_mh if mh else respack.hold_head_h
    mid_h = max(1, ih - head_h - tail_h)

    head_src = img.subsurface((0, 0, iw, head_h))
    mid_src = img.subsurface((0, head_h, iw, mid_h))
    tail_src = img.subsurface((0, head_h + mid_h, iw, tail_h))

    vx = tail_xy[0] - head_xy[0]
    vy = tail_xy[1] - head_xy[1]
    length = math.hypot(vx, vy)
    if length < 1e-3:
        return
    ang = math.atan2(vy, vx)

    target_w_raw = max(2, int(hold_body_w * size_scale))

    def _clip_segment_to_aabb(
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        xmin: float,
        ymin: float,
        xmax: float,
        ymax: float,
    ) -> Optional[Tuple[float, float]]:
        dx = float(x1) - float(x0)
        dy = float(y1) - float(y0)
        t0 = 0.0
        t1 = 1.0

        def _clip(p: float, q: float) -> bool:
            nonlocal t0, t1
            if abs(p) < 1e-12:
                return q >= 0.0
            r = q / p
            if p < 0.0:
                if r > t1:
                    return False
                if r > t0:
                    t0 = r
            else:
                if r < t0:
                    return False
                if r < t1:
                    t1 = r
            return True

        if not _clip(-dx, float(x0) - float(xmin)):
            return None
        if not _clip(dx, float(xmax) - float(x0)):
            return None
        if not _clip(-dy, float(y0) - float(ymin)):
            return None
        if not _clip(dy, float(ymax) - float(y0)):
            return None
        if t1 < t0:
            return None
        return (t0, t1)

    ow = float(overlay.get_width())
    oh = float(overlay.get_height())
    m = float(target_w_raw) * 1.5
    clip = _clip_segment_to_aabb(
        float(head_xy[0]),
        float(head_xy[1]),
        float(tail_xy[0]),
        float(tail_xy[1]),
        -m,
        -m,
        ow + m,
        oh + m,
    )
    if clip is None:
        return
    t_clip0, t_clip1 = clip
    clip_hide_head = t_clip0 > 1e-6
    clip_hide_tail = t_clip1 < 1.0 - 1e-6
    head_xy = (
        float(head_xy[0]) + float(vx) * float(t_clip0),
        float(head_xy[1]) + float(vy) * float(t_clip0),
    )
    tail_xy = (
        float(head_xy[0]) + float(vx) * float(t_clip1),
        float(head_xy[1]) + float(vy) * float(t_clip1),
    )
    vx = float(tail_xy[0]) - float(head_xy[0])
    vy = float(tail_xy[1]) - float(head_xy[1])
    length = math.hypot(vx, vy)
    if length < 1e-3:
        return
    ang = math.atan2(vy, vx)

    out_h_raw = int(max(2, length))

    # Calculate rotation angle for cache key
    v = pygame.math.Vector2(float(vx), float(vy))
    v_len = float(v.length())
    if v_len < 1e-6:
        return
    v_m = pygame.math.Vector2(float(v.x), float(-v.y))
    base_m = pygame.math.Vector2(0.0, 1.0)
    rot_deg = float(base_m.angle_to(v_m))

    hold_cache = get_global_hold_cache()

    out_w, out_h, rot_q_deg, progress_q = hold_cache.quantize(target_w_raw, out_h_raw, rot_deg, progress)
    rot_q_deg_f = float(rot_q_deg)
    scale = float(out_w) / max(1, iw)
    tail_len = tail_h * scale
    head_len = head_h * scale

    cached_surf = hold_cache.get(out_w, out_h, rot_q_deg_f, mh, progress_q, note_rgb)

    if cached_surf is not None:
        if a >= 255:
            spr = cached_surf
        else:
            spr = cached_surf.copy()
            spr.set_alpha(a)
    else:
        # Render hold surface from scratch
        # Use surface pool to avoid per-frame allocation
        pool = get_global_pool()
        surf = pool.get(out_w, out_h, pygame.SRCALPHA)
        pooled_surf = surf

        def _blit_mid(y0: int, seg_h: int, repeat: bool):
            if seg_h <= 0:
                return
            if not repeat:
                piece = pygame.transform.smoothscale(mid_src, (out_w, int(seg_h)))
                surf.blit(piece, (0, int(y0)))
                return
            tile_h = max(1, int(mid_src.get_height() * scale))
            tile = pygame.transform.smoothscale(mid_src, (out_w, tile_h))
            yy = int(y0)
            y_end = int(y0 + seg_h)
            while yy < y_end:
                surf.blit(tile, (0, yy))
                yy += tile_h

        try:
            head_piece = pygame.transform.smoothscale(head_src, (out_w, max(1, int(round(head_len)))))
        except:
            head_piece = head_src
        try:
            tail_piece = pygame.transform.smoothscale(tail_src, (out_w, max(1, int(round(tail_len)))))
        except:
            tail_piece = tail_src

        head_draw_h = min(int(out_h), int(head_piece.get_height()))
        tail_no_scale = bool(getattr(respack, "hold_tail_no_scale", False))
        if tail_no_scale:
            tail_draw_h = int(tail_piece.get_height())
        else:
            tail_draw_h = min(int(out_h), int(tail_piece.get_height()))

        keep_head = bool(getattr(respack, "hold_keep_head", False))
        hide_head_now = ((progress_q is not None) and (not keep_head)) or bool(clip_hide_head)
        if clip_hide_tail:
            tail_draw_h = 0

        y0_mid = 0 if hide_head_now else int(head_draw_h)
        y1_mid = int(out_h - tail_draw_h)
        mid_h_draw = int(max(0, y1_mid - y0_mid))
        _blit_mid(y0_mid, mid_h_draw, repeat=bool(getattr(respack, "hold_repeat", False)))

        if (not hide_head_now) and head_draw_h > 0:
            try:
                surf.blit(head_piece.subsurface((0, 0, out_w, head_draw_h)), (0, 0))
            except:
                surf.blit(head_piece, (0, 0))

        if (not clip_hide_tail) and tail_draw_h > 0:
            try:
                if tail_no_scale:
                    tail_draw_piece = tail_piece
                elif tail_piece.get_height() != int(tail_draw_h):
                    tail_draw_piece = pygame.transform.smoothscale(tail_piece, (out_w, int(tail_draw_h)))
                else:
                    tail_draw_piece = tail_piece
                surf.blit(tail_draw_piece, (0, int(out_h - tail_draw_h)))
            except:
                surf.blit(tail_piece, (0, int(out_h - tail_piece.get_height())))

        # During holding, allow sampling only the "tail side" portion of the texture and stretch it
        # back to the current geometric length. This makes the texture appear to be "consumed".
        if (progress_q is not None) and (not keep_head) and bool(getattr(respack, "hold_compact", False)):
            try:
                p = clamp(float(progress_q), 0.0, 1.0)
            except:
                p = None
            if p is not None and p > 1e-6:
                keep = clamp(1.0 - float(p), 0.02, 1.0)
                try:
                    # When head is hidden, only crop the body+tail portion
                    if hide_head_now:
                        effective_h = out_h - head_draw_h  # body+tail height
                        sample_h = max(2, int(round(float(effective_h) * float(keep))))
                        y0 = head_draw_h + (effective_h - sample_h)
                    else:
                        sample_h = max(2, int(round(float(out_h) * float(keep))))
                        y0 = max(0, int(out_h) - int(sample_h))
                    crop = surf.subsurface((0, int(y0), int(out_w), int(sample_h))).copy()
                    if pooled_surf is not None:
                        try:
                            pool.release(pooled_surf)
                        except Exception:
                            pass
                        pooled_surf = None
                    surf = pygame.transform.smoothscale(crop, (int(out_w), int(out_h)))
                except:
                    pass

        try:
            tr, tg, tb = note_rgb
            tint_s = pool.get(surf.get_width(), surf.get_height(), pygame.SRCALPHA)
            tint_s.fill((int(tr), int(tg), int(tb), 255))
            surf.blit(tint_s, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            pool.release(tint_s)
        except:
            pass

        spr = pygame.transform.rotozoom(surf, rot_q_deg_f, 1.0)
        if pooled_surf is not None:
            try:
                pool.release(pooled_surf)
            except Exception:
                pass

        # Cache the rotated surface for reuse
        hold_cache.put(out_w, out_h, rot_q_deg_f, mh, progress_q, note_rgb, spr)

        if a < 255:
            spr = spr.copy()
            spr.set_alpha(a)

    # Blit the hold surface (cached or freshly rendered)
    # Anchor: align the head end of the (rotated) sprite to head_xy.
    try:
        off = pygame.math.Vector2(0.0, float(out_h) * 0.5)
        off_m = pygame.math.Vector2(float(off.x), float(-off.y))
        off_m = off_m.rotate(rot_q_deg_f)
        off = pygame.math.Vector2(float(off_m.x), float(-off_m.y))
        cx = float(head_xy[0]) - float(off.x)
        cy = float(head_xy[1]) - float(off.y)
        rect = spr.get_rect(center=(cx, cy))
        overlay.blit(spr, rect.topleft)
    except:
        overlay.blit(spr, (head_xy[0] - spr.get_width() / 2, head_xy[1] - spr.get_height() / 2))

    if draw_outline:
        hw = float(out_w) * 0.5
        nx, ny = -math.sin(ang), math.cos(ang)
        pts = [
            (head_xy[0] + nx * hw, head_xy[1] + ny * hw),
            (head_xy[0] - nx * hw, head_xy[1] - ny * hw),
            (tail_xy[0] - nx * hw, tail_xy[1] - ny * hw),
            (tail_xy[0] + nx * hw, tail_xy[1] + ny * hw),
        ]
        draw_poly_outline_rgba(overlay, pts, (*line_rgb, a), width=max(1, int(outline_width)))
